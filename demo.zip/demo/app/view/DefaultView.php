<html>
  <head>
    <title>My Demo Page</title>
  </head>
  <body>
    <h1>Demo</h1>
    <?php pre($data);
    pre(indexBy($data, 'keywords_id'));
    ?>
  </body>
</html>

